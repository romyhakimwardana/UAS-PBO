/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GUI;
import Database.Pakaian;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CrudPakaian extends javax.swing.JFrame {
    Pakaian k;
    int Id_Pakaian, Harga, Ukuran;
    String Nama, Warna;
    public CrudPakaian() {
    
    initComponents();
    k = new Pakaian();
    setobjek(false);
    baru.setEnabled(true);
    simpan.setEnabled(false);
    canceledit.setVisible(false);
    this.setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        txtnama = new javax.swing.JTextField();
        txtharga = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        baru = new javax.swing.JButton();
        update = new javax.swing.JButton();
        simpan = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        canceledit = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbmenu = new javax.swing.JTable();
        peringatan = new javax.swing.JLabel();
        txtUkuran = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtWarna = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 0, 51));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Lucida Console", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 153, 204));
        jLabel1.setText("Input Data");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(201, 6, -1, -1));

        jLabel2.setFont(new java.awt.Font("Lucida Console", 0, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 153, 204));
        jLabel2.setText("ID             :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 52, 200, -1));

        jLabel3.setFont(new java.awt.Font("Lucida Console", 0, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 153, 204));
        jLabel3.setText("Nama           : ");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 83, -1, -1));

        jLabel4.setFont(new java.awt.Font("Lucida Console", 0, 11)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 204));
        jLabel4.setText("Ukuran         :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 160, 25));

        txtid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidActionPerformed(evt);
            }
        });
        getContentPane().add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 40, 279, -1));

        txtnama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnamaActionPerformed(evt);
            }
        });
        getContentPane().add(txtnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, 279, -1));

        txtharga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txthargaActionPerformed(evt);
            }
        });
        txtharga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txthargaKeyTyped(evt);
            }
        });
        getContentPane().add(txtharga, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 279, -1));

        jLabel5.setFont(new java.awt.Font("Lucida Console", 0, 11)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 153, 204));
        jLabel5.setText("Warna          :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 130, -1));

        baru.setFont(new java.awt.Font("Lucida Console", 0, 10)); // NOI18N
        baru.setText("Baru");
        baru.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baruActionPerformed(evt);
            }
        });
        getContentPane().add(baru, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 190, 80, -1));

        update.setFont(new java.awt.Font("Lucida Console", 0, 10)); // NOI18N
        update.setText("Update");
        update.setEnabled(false);
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 190, 70, -1));

        simpan.setFont(new java.awt.Font("Lucida Console", 0, 10)); // NOI18N
        simpan.setText("Simpan");
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });
        getContentPane().add(simpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 250, 80, -1));

        hapus.setFont(new java.awt.Font("Lucida Console", 0, 10)); // NOI18N
        hapus.setText("Hapus");
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });
        getContentPane().add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 190, 70, -1));

        edit.setFont(new java.awt.Font("Lucida Console", 0, 10)); // NOI18N
        edit.setText("Edit");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });
        getContentPane().add(edit, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 279, -1));

        canceledit.setFont(new java.awt.Font("Lucida Console", 0, 10)); // NOI18N
        canceledit.setText("Cancel Edit");
        canceledit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                canceleditMouseClicked(evt);
            }
        });
        canceledit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                canceleditActionPerformed(evt);
            }
        });
        getContentPane().add(canceledit, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 250, -1, -1));

        jLabel7.setFont(new java.awt.Font("Lucida Console", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 204));
        jLabel7.setText("List Pakaian     :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 279, 170, -1));

        tbmenu.setBackground(new java.awt.Color(204, 204, 204));
        tbmenu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tbmenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbmenuMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbmenu);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(2, 298, 470, 190));
        getContentPane().add(peringatan, new org.netbeans.lib.awtextra.AbsoluteConstraints(424, 133, -1, -1));
        getContentPane().add(txtUkuran, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 130, 280, -1));

        jLabel6.setFont(new java.awt.Font("Lucida Console", 0, 11)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 204));
        jLabel6.setText("Harga          :");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 102, 160, 25));
        getContentPane().add(txtWarna, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 280, -1));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 470, 500));

        jMenu1.setText("File");

        jMenuItem1.setText("Kembali");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuItem2.setText("Keluar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txthargaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txthargaKeyTyped
        // TODO add your handling code here:
        char enter = evt.getKeyChar();
        if(Character.isAlphabetic(enter)){
            evt.consume();
            peringatan.setVisible(true);
            peringatan.setText("Inputan harus angka");
        } else {
            peringatan.setVisible(false);
        }
    }//GEN-LAST:event_txthargaKeyTyped

    private void baruActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baruActionPerformed
        // TODO add your handling code here:
        setobjek(true);
        baru();
        txtid.requestFocus();
        simpan.setEnabled(true);
        update.setEnabled(false);
        edit.setEnabled(false);
        hapus.setEnabled(false);
        canceledit.setVisible(true);
    }//GEN-LAST:event_baruActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        updatedata();
        update.setEnabled(false);
        edit.setEnabled(true);
        simpan.setEnabled(false);
        hapus.setEnabled(false);
        baru.setEnabled(false);
        canceledit.setVisible(false);
    }//GEN-LAST:event_updateActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:
        simpandata();
        baru();
        baru.setEnabled(true);
        simpan.setEnabled(true);
        hapus.setEnabled(true);
        update.setEnabled(true);
        edit.setEnabled(true);
        canceledit.setVisible(true);
    }//GEN-LAST:event_simpanActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // TODO add your handling code here:
        hapusdata();
        baru.setEnabled(true);
        simpan.setEnabled(false);
        hapus.setEnabled(false);
        update.setEnabled(false);
        edit.setEnabled(false);
        canceledit.setVisible(true);
    }//GEN-LAST:event_hapusActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
        setobjek(true);
        edit.setVisible(true);
        update.setEnabled(true);
        simpan.setEnabled(true);
        hapus.setEnabled(true);
        baru.setEnabled(true);
        edit.setEnabled(false);
        canceledit.setVisible(true);
        txtid.setEnabled(true);
    }//GEN-LAST:event_editActionPerformed

    private void canceleditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_canceleditActionPerformed
        // TODO add your handling code here:
        baru();
        baru.setEnabled(false);
        update.setEnabled(false);
        simpan.setEnabled(false);
        hapus.setEnabled(false);
        edit.setEnabled(true);
    }//GEN-LAST:event_canceleditActionPerformed

    private void txtnamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnamaActionPerformed

    private void txthargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txthargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txthargaActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        tampildata();
    }//GEN-LAST:event_formWindowOpened

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
       new FormPakaian().show();
       dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        dispose();
        JOptionPane.showMessageDialog(null, "Terima Kasih");

        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void canceleditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_canceleditMouseClicked
     canceledit.setVisible(false);
     update.setEnabled(false);
    }//GEN-LAST:event_canceleditMouseClicked

    private void tbmenuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbmenuMouseClicked
        // TODO add your handling code here:
        baru();
        baru.setEnabled(true);
        update.setEnabled(true);
        simpan.setEnabled(true);
        hapus.setEnabled(true);
        edit.setEnabled(true);
        if(update.isEnabled()){
            setformtable();
        }
    }//GEN-LAST:event_tbmenuMouseClicked

    private void txtidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CrudPakaian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CrudPakaian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CrudPakaian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CrudPakaian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrudPakaian().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton baru;
    private javax.swing.JButton canceledit;
    private javax.swing.JButton edit;
    private javax.swing.JButton hapus;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel peringatan;
    private javax.swing.JButton simpan;
    private javax.swing.JTable tbmenu;
    private javax.swing.JTextField txtUkuran;
    private javax.swing.JTextField txtWarna;
    private javax.swing.JTextField txtharga;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtnama;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
private void simpandata() {
        Id_Pakaian = Integer.parseInt(txtid.getText());
       
        Nama = txtnama.getText();
        Harga = Integer.parseInt(txtharga.getText());
        Ukuran = Integer.parseInt(txtUkuran.getText());
        Warna = txtWarna.getText();
        
        if (txtid.getText().isEmpty() || txtnama.getText().isEmpty() || txtharga.getText().isEmpty() || txtUkuran.getText().isEmpty() || txtWarna.getText().isEmpty()) {
          JOptionPane.showMessageDialog(rootPane,"data harus diisi","informasi",JOptionPane.INFORMATION_MESSAGE);
        } else {
            System.out.println("jim");
        k.simpandata(Id_Pakaian, Nama, Warna, Ukuran,Harga );
        JOptionPane.showMessageDialog(rootPane,"Data berhasil disimpan","Informasi",JOptionPane.INFORMATION_MESSAGE);
        tampildata();
        baru();
        setobjek(false);
        }
        
}

private void tampildata () {
    DefaultTableModel dtm = (DefaultTableModel) tbmenu.getModel();
    dtm.setRowCount(0);
    dtm.setColumnCount(0);
    k.tampildata(dtm);
    tbmenu.setModel(dtm);
}

private void setformtable() {
     txtid.setText(tbmenu.getValueAt(tbmenu.getSelectedRow(), 0).toString());
     txtnama.setText(tbmenu.getValueAt(tbmenu.getSelectedRow(), 1).toString());
     txtharga.setText(tbmenu.getValueAt(tbmenu.getSelectedRow(), 2).toString());
     txtUkuran.setText(tbmenu.getValueAt(tbmenu.getSelectedRow(), 3).toString());
     txtWarna.setText(tbmenu.getValueAt(tbmenu.getSelectedRow(), 4).toString());
     
     
}

private void hapusdata() {
    Id_Pakaian = Integer.parseInt(tbmenu.getValueAt(tbmenu.getSelectedRow(), 0).toString());
    
    int conf = JOptionPane.showConfirmDialog(rootPane,"Apakah anda yakin akan menghapus data ini ?","Konfirmasi",JOptionPane.YES_NO_OPTION);
    if (conf == 0) {
        k.hapusdata(Id_Pakaian);
    JOptionPane.showMessageDialog(rootPane,"Data berhasil dihapus","Informasi",JOptionPane.INFORMATION_MESSAGE);
    tampildata();
    baru();
    setobjek(false);
    }
    
} 

private void updatedata() {
        Id_Pakaian = Integer.parseInt(tbmenu.getValueAt(tbmenu.getSelectedRow(), 0).toString());
        Nama = txtnama.getText();
        Harga = Integer.parseInt(txtharga.getText());
        Ukuran = Integer.parseInt(txtUkuran.getText());
        Warna = txtWarna.getText();
        
        
        
        int conf = JOptionPane.showConfirmDialog(rootPane,"Apakah anda yakin akan mengubah data ini ?","Konfirmasi",JOptionPane.YES_NO_OPTION);
        if (conf == 0) {
            k.updatedata(Id_Pakaian, Nama, Harga, Ukuran, Warna);
            tampildata();
            JOptionPane.showMessageDialog(rootPane,"Data berhasil diupdate","Informasi",JOptionPane.INFORMATION_MESSAGE);
            baru();
            setobjek(false);
        }
    }

private void baru() {
    txtid.setText(null);
    txtnama.setText(null);
    txtharga.setText(null);
    txtUkuran.setText(null);
    txtWarna.setText(null);
  
}

private void setobjek(boolean b) {
    txtid.setEnabled(b);
    txtnama.setEnabled(b);
    txtharga.setEnabled(b);
    txtUkuran.setEnabled(b);
    txtWarna.setEnabled(b);
}

}