package Database;
import static Database.DbConnect.connect;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Pakaian extends DbConnect {
    public Pakaian(){
        connect();
    }
    
    public void simpandata(int Id_Pakaian, String Nama, String Warna,  int Ukuran, int Harga){
    try{
        String sql = "INSERT INTO pakaian VALUES ('"+Id_Pakaian+"','"+Nama+"','"+Warna+"','"+Ukuran+"','"+Harga+"')";
        stm = con.createStatement();
        stm.execute(sql);
        
        System.out.println("Simpan Data Berhasil");
    }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
    }
    }

public void tampildata (DefaultTableModel dtm){
        dtm.addColumn("Id_Pakaian");
        dtm.addColumn("Nama");
        dtm.addColumn("Harga");
        dtm.addColumn("Ukuran");
        dtm.addColumn("Warna");
        String sql = "SELECT * FROM pakaian";
        try {
            rs = stm.executeQuery(sql);
            
            while(rs.next()) {
                dtm.addRow(new Object[]{
                rs.getInt("Id_Pakaian"),
                rs.getString("Nama"),
                rs.getInt("Harga"),
                rs.getInt("Ukuran"),
                rs.getString("Warna")
                });

            }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
}
public void updatedata(int Id_Pakaian, String Nama, int Harga,  int Ukuran, String Warna) {
         String sql = "UPDATE pakaian SET Nama = '"+Nama+"', Warna = '"+Warna+"', Ukuran = '"+Ukuran+"', Harga = '"+Harga+"'  WHERE Id_Pakaian = '"+Id_Pakaian+"'";
        try {
            stm.executeUpdate(sql);
        } catch (Exception e) {
}
}

public void hapusdata(int Id_Pakaian) {
         String sql = "DELETE FROM pakaian WHERE Id_Pakaian = '"+Id_Pakaian+"'";
        try {
            stm.executeUpdate(sql);
        } catch (Exception e) {

}
}

    public ResultSet cari(String cari) throws Exception {
          String sql = "SELECT * FROM pakaian WHERE Id_Pakaian = '"+cari+"'";
          return rs = stm.executeQuery(sql);
      }

    public ResultSet caridata(DefaultTableModel dtm, String cari) {
        try {
            String sql = "SELECT * FROM pakaian WHERE Id_Pakaian LIKE '%"+cari+"%' OR Nama LIKE '%"+cari+"%' OR Harga LIKE '%"+cari+"%'";
            rs = stm.executeQuery(sql);
            Object [] data = new Object[5];
                while(rs.next()) {
                data[0] = rs.getInt("Id_Pakaian");
                data[1] = rs.getString("Nama");
                data[2] = rs.getInt("Harga");
                data[3] = rs.getInt("Ukuran");
                data[4] = rs.getString("Warna");
                dtm.addRow(data);
                
             }
        } catch (Exception ex) {
            
        }
        return rs;

}
}
