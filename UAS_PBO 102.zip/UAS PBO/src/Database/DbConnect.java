package Database;

import GUI.CrudPakaian;
import GUI.FormPakaian;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DbConnect {
    public static String username = "root";
    public static String password = "";
    public static ResultSet rs;
    public static Connection con;
    public static Statement stm;
    static final String DB_URL ="jdbc:mysql://localhost/distropedia";
    
    public static Connection connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL,username,password);
            stm = con.createStatement();
            System.out.println("koneksi Berhasil;");
        } catch (Exception e) {
            System.out.println("koneksi Gagal" );
        } 
        return con;
    }
public static void main(String[] args) {
         System.out.println("los");
         CrudPakaian crud = new CrudPakaian();
         crud.setVisible(true);
         FormPakaian form = new FormPakaian();
         form.setVisible(true);
         
    }
}