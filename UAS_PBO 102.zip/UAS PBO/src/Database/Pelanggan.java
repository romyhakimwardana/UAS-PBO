package Database;
import static Database.DbConnect.connect;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Pelanggan extends DbConnect {
    public Pelanggan(){
        connect();
    }
    
    public void simpandata(int Id, String Nama_Pelanggan, String Jenis_Kelamin, String Tanggal_Lahir, int Id_Pakaian){
    try{
        String sql = "INSERT INTO pelanggan VALUES ('"+Id+"','"+Nama_Pelanggan+"','"+Jenis_Kelamin+"','"+Tanggal_Lahir+"','"+Id_Pakaian+"')";
        stm = con.createStatement();
        stm.execute(sql);
        
        System.out.println("Simpan Data Berhasil");
    }catch (Exception e) {
        JOptionPane.showMessageDialog(null, e);     
//        System.out.println("Simpan Data Gagal");
    }
    }

public void tampildata (DefaultTableModel dtm){
        dtm.addColumn("Id");
        dtm.addColumn("Nama_Pelanggan");
        dtm.addColumn("Jenis_Kelamin");
        dtm.addColumn("Tanggal_Lahir");
        dtm.addColumn("Id_Pakaian");
        String sql = "SELECT * FROM pelanggan";
        try {
            rs = stm.executeQuery(sql);
            
            while(rs.next()) {
                dtm.addRow(new Object[]{
                rs.getInt("Id"),
                rs.getString("Nama_Pelanggan"),
                rs.getString("Jenis_Kelamin"),
                rs.getString("Tanggal_Lahir"),
                rs.getString("Id_Pakaian")
                });

            }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
}
    
public void tampildata1 (DefaultTableModel dtm){
        dtm.addColumn("Id");
        dtm.addColumn("Nama_Pelanggan");
        dtm.addColumn("Jenis_Kelamin");
        dtm.addColumn("Tanggal_Lahir");
        dtm.addColumn("Id_Pakaian");
        dtm.addColumn("Nama Baju");
        String sql = "SELECT * FROM pelanggan INNER JOIN pakaian ON pelanggan.Id_Pakaian = pakaian.Id_Pakaian";
        try {
            rs = stm.executeQuery(sql);
            
            while(rs.next()) {
                dtm.addRow(new Object[]{
                rs.getInt("Id"),
                rs.getString("Nama_Pelanggan"),
                rs.getString("Jenis_Kelamin"),
                rs.getString("Tanggal_Lahir"),
                rs.getString("Id_Pakaian"),
                rs.getString("Nama")
                });

            }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
}
public void updatedata(int Id, String Nama_Pelanggan, String Jenis_Kelamin, String Tanggal_Lahir, int Id_Pakaian) {
         String sql = "UPDATE pelanggan SET Nama_Pelanggan = '"+Nama_Pelanggan+"', Jenis_Kelamin = '"+Jenis_Kelamin+"', Tanggal_Lahir = '"+Tanggal_Lahir+"', Id_Pakaian = '"+Id_Pakaian+"' WHERE Id = '"+Id+"'";
        try {
            stm.executeUpdate(sql);
        } catch (Exception e) {
}
}

public void hapusdata(int Id) {
         String sql = "DELETE FROM pelanggan WHERE Id = '"+Id+"'";
        try {
            stm.executeUpdate(sql);
        } catch (Exception e) {

}
}

    public ResultSet cari(String cari) throws Exception {
          String sql = "SELECT * FROM pelanggan WHERE Id = '"+cari+"'";
          return rs = stm.executeQuery(sql);
      }

    public ResultSet caridata(DefaultTableModel dtm, String cari) {
        try {
            String sql = "SELECT * FROM pelanggan WHERE Id LIKE '%"+cari+"%' OR Nama_Pelanggan LIKE '%"+cari+"%' OR Jenis_Kelamin LIKE '%"+cari+"%'";
            rs = stm.executeQuery(sql);
            Object [] data = new Object[5];
                while(rs.next()) {
                data[0] = rs.getInt("Id");
                data[1] = rs.getString("Nama_Pelanggan");
                data[2] = rs.getString("Jenis_Kelamin");
                data[3] = rs.getString("Tanggal_Lahir");
                data[4] = rs.getInt("Id_Pakaian");

                dtm.addRow(data);
                
             }
        } catch (Exception ex) {
            
        }
        return rs;

}
}