package Database;
import GUI.CrudPakaian;
import GUI.FormPakaian;
import java.sql.ResultSet;

public class Login extends DbConnect {
     public Login(){
       
    }
     
  public static void insert_admin(String Username, String Password){
    try{
        
        String sql = "INSERT INTO login(Username ,Password) VALUES('"+Username+"','"+Password+"')";
        stm = con.createStatement();
        stm.execute(sql);
        
        System.out.println("Tambah Data Berhasil");
    }catch (Exception e) {
            System.out.println("Tambah Data Gagal");
    }
    }
  
  public static void delete_admin(String Username, String Password){
    try{
        String sql = "DELETE FROM login WHERE Username ='"+Username+"'";
        stm = connect().createStatement();
        stm.execute(sql);
        
        System.out.println("Hapus Data Berhasil");
        
    }catch (Exception e) {
            System.out.println("Hapus Data Gagal");
    }
    }
     
   public static void read_admin(String Username, String Password) {
         try {
            String sql = "SELECT * FROM login WHERE Username ="+Username+"','"+Password+"'";
            stm = connect().createStatement();
            stm.execute(sql);
            ResultSet rs = stm.executeQuery(sql);
            rs.next();
            System.out.println("Username :" +rs.getString("Username"));
            System.out.println("Password :" +rs.getString("Password"));
            
        } catch (Exception e) {
            
        }
    }
   
   public static void read_admin_all() {
         try {
            String sql = "SELECT * FROM login";
            stm = connect().createStatement();
            stm.execute(sql);
            ResultSet rs = stm.executeQuery(sql);
            rs.next();
            System.out.println("Username :" +rs.getString("Username"));
            System.out.println("Password :" +rs.getString("Password"));
            
        } catch (Exception e) {

             System.out.println("Ambil Data Gagal");
        }
  
    
    }
   
    public static void main(String[] args) {
        connect();
        FormPakaian p = new FormPakaian();
        p.setVisible(true);  
       CrudPakaian crud = new CrudPakaian();
       crud.setVisible(true);
    }
}